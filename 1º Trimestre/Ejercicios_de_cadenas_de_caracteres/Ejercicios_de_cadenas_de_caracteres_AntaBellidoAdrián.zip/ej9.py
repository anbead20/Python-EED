"""
Este programa sustituye las vocales 'a', 'e', 'i', 'o' por los números '4', '3', '1' y '0'
respectivamente en una cadena de texto proporcionada por el usuario.
Autor: Adrián Anta Bellido
"""

# Presentación del programa
print("Este programa sustituye las vocales 'a', 'e', 'i', 'o' por los números '4', '3', '1' y '0' respectivamente")
print("----------------------------------------------------------------------------------------------------------\n")

# Solicitar la cadena de texto al usuario
text = input("Ingrese la cadena de texto: ")

# Crear la nueva cadena con las sustituciones
modified_text = ""
for char in text:
    if char == 'a':
        modified_text += '4'
    elif char == 'e':
        modified_text += '3'
    elif char == 'i':
        modified_text += '1'
    elif char == 'o':
        modified_text += '0'
    else:
        modified_text += char

# Mostrar la cadena resultante
print("La cadena modificada es:", modified_text)

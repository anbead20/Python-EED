"""
Este programa calcula la ganancia obtenida por un productor de uva según el tipo, tamaño y precio inicial del kilo de uva.
Autor: Adrián Anta Bellido
"""

# Entrada de los datos
initial_price = float(input("Ingrese el precio inicial por kilo de uva: "))
type_uva = input("Ingrese el tipo de uva (A o B): ").upper()
size_uva = int(input("Ingrese el tamaño de la uva (1 o 2): "))
kilos = float(input("Ingrese la cantidad de kilos de uva: "))

# Determinación del ajuste al precio por tipo y tamaño
match (type_uva, size_uva):
    case ('A', 1):
        final_price = initial_price + 0.20
    case ('A', 2):
        final_price = initial_price + 0.30
    case ('B', 1):
        final_price = initial_price - 0.30
    case ('B', 2):
        final_price = initial_price - 0.50
    case _:
        print("ERROR: Tipo o tamaño de uva no válidos.")
        exit()

# Cálculo de la ganancia total
total_gain = final_price * kilos

# Mostrar la ganancia obtenida
print(f"La ganancia obtenida por el productor es: {total_gain:.2f} euros.")

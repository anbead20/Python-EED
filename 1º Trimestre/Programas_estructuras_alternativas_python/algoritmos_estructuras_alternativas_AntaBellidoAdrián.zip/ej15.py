"""
Este programa determina el costo del viaje de estudios por alumno y el total a pagar a la compañía de autobuses.
Autor: Adrián Anta Bellido
"""

# Entrada del número de alumnos
num_students = int(input("Ingrese el número de alumnos: "))

# Determinación del costo por alumno o costo total si son menos de 30
if num_students >= 100:
    cost_per_student = 65
    total_cost = num_students * cost_per_student
elif 50 <= num_students <= 99:
    cost_per_student = 70
    total_cost = num_students * cost_per_student
elif 30 <= num_students <= 49:
    cost_per_student = 95
    total_cost = num_students * cost_per_student
else:
    total_cost = 4000
    cost_per_student = total_cost / num_students

# Mostrar el costo total y el costo por alumno
print(f"El pago total a la compañía de autobuses es: {total_cost:.2f} euros.")
print(f"Cada alumno debe pagar: {cost_per_student:.2f} euros.")
